
package ui;

import java.util.Scanner;

import model.WetlandControler;

public class WeatlandManager{
    public static Scanner reader;
    public static WetlandControler controller;
    
    
	public static void main(String[] args)   {
        Start();
        mainMenu();
		
       
     }
    public static void Start(){
       
        reader = new Scanner(System.in);
        controller= new WetlandControler();

    }


    public static void mainMenu(){
        boolean flag=true;
		System.out.println("welcome to the weatland 2000");
        
        while(flag==true){
            
            System.out.println("menu:\n1.create weatland\n2.register a new specie\n3.register a new event\n4.show the number of mantenance for the wetlands\n5.show the wetland with less species\n6.screach specie\n7.show wetland information\n8.show the wetland with more species\n9.exit");
        
            int mainOption = reader.nextInt();
            
            switch( mainOption){
                
            case 1:
                registerWetland();
                    break;

            case 2:
            	registerSpecie();
                 break;

            case 3:
            	registerEvent();
                    break;

             case 4:
            	 screachMaintenance();
                break;
            case 5:
            	screachSpecies();
                    break;
            case 6:
                    break;
            case 7:
            	System.out.println(controller.showWetlands());
                    break;

            case 8:
                    break;
            case 9:
                System.out.println("thanks for using wetland 2000 see you later :)");
                flag=false;
                    break;

            default:
                    System.out.println("You choose a invalid option.please choose again");
                    break;    
        
             }
                

         }

    }
    private static void registerWetland(){

    	System.out.println("enter the name of the wetland");
        String wetlandName=reader.nextLine();
        wetlandName=reader.nextLine();

        System.out.println("enter the ubication of th wetland (rural/urban)");
        String ubicationZone=reader.nextLine();
        System.out.println("enter the name of the commune/neighborhood where is ocated the wetland ");
        String ubicationName=reader.nextLine();
        System.out.println("the wetland is a protected area?(yes/no)");
       String protectedArea=reader.nextLine();

        System.out.println("enter the type of ubicacion of the wetland (public/private)");
        String ubicationType=reader.nextLine();

        System.out.println("enter the number of kilometers of the wetland");
        double numberKm=reader.nextDouble();

        System.out.println("enter the photo url of the wetland");
        String photo=reader.nextLine();
        photo=reader.nextLine();
        
        
        if (controller.registerWetland(wetlandName,ubicationZone,ubicationType,photo, numberKm, protectedArea,ubicationName)) {
			System.out.println("The wetland " + wetlandName + " was successfully registered");
		} else {
			System.out.println("The wetland " + wetlandName + " couldn't be registered");
		}


    }
    
    private static void registerSpecie() {
    	
    	if (controller.showWetlandsList().equals("")) {

			System.out.println("There aren't any Wetlands registered.");
		} else {
			System.out.println("These are the Wetlands currently registered:" + controller.showWetlandsList());
			System.out.println("Type the ID of the wetland that you want to register a sepecie: ");
			String wetlandID = reader.next();
			
			System.out.println("enter the name of the specie");
			String name=reader.nextLine();
			name=reader.nextLine();
			System.out.println("enter the cientific name of the Specie");
			String cientificName=reader.nextLine();
			System.out.println("the specie is migratory? (yes/no)");
			String migratorySpecie=reader.nextLine();
			System.out.println("enter the type of flora");
			String typeFlora=reader.nextLine();
				if (controller.registerSpecie(wetlandID,name,cientificName,migratorySpecie,typeFlora)) {
					System.out.println("The Specie " + name + " was successfully registered");
						} else {
							System.out.println("The Specie " + name + " couldn't be registered");
								}
    	
				}		
    }
    	
    
    private static void registerEvent() {
    	if (controller.showWetlandsList().equals("")) {

			System.out.println("There aren't any Wetlands registered.");
		} else {
			System.out.println("These are the Wetlands currently registered:" + controller.showWetlandsList());
			System.out.println("Type the ID of the Team you want to register a Player: ");
			String wetlandID = reader.next();
    	

		System.out.println("Type the event date (YYYY-MM-DD): ");
		String eventDate = reader.next();

			int year = Integer.parseInt(eventDate.split("-")[0]);
			int month = Integer.parseInt(eventDate.split("-")[1]);
			int day = Integer.parseInt(eventDate.split("-")[2]);
			
		System.out.println("enter the type of event for the wetland\n1.maintenance\n2.school visit\n3.improvement activity\n4.celbration");
		String typeEvent=reader.nextLine();
		
		System.out.println("enter the name of the owner for the event");
		String ownerEvent=reader.nextLine();
		ownerEvent=reader.nextLine();
		System.out.println("enter the cost for the event");
		double eventCost=reader.nextDouble();
		System.out.println("enter a description for the event");
		String eventDescription=reader.nextLine();
		eventDescription=reader.nextLine();
		
		if (controller.registerEvent(wetlandID, typeEvent,ownerEvent,eventCost, eventDescription, day, month, year)) {
			System.out.println("The event of " + ownerEvent + " was successfully registered");
				} else {
					System.out.println("The event of " + ownerEvent + " couldn't be registered");
						}
		}
		
		
		
		}
    private static void screachMaintenance() {
    	
    	System.out.println("type the date in that do you want to screach the number of mantenances (YYYY-MM-DD)" );
    	
    	
    	
    }
    
    private static void screachSpecies() {
    	
    	System.out.println("enter the name of the specie that you want to screach");
    	
    	String name=reader.nextLine();
    	
    	
    }
    
    
    
    
    

		
			
			
			
}
    	
    	
    	
    	
    	
    	
    	
    	
    
    
    

