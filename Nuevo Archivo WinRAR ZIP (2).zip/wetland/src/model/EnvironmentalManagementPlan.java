package model;

public class EnvironmentalManagementPlan {

    private String compilancePorcentage;


    public EnvironmentalManagementPlan(String compilancePorcentage){

        this.compilancePorcentage=compilancePorcentage;

    }
    public String getCompilancePorcentage() {
		return compilancePorcentage;
	}

	public void setCompilancePorcentage(String compilancePorcentage) {
		this.compilancePorcentage = compilancePorcentage;
	}

    

    
}
